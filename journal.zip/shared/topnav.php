<div class="px-4 py-1">
    <div class="d-flex justify-content-between align-items-center">
        <a href="index.php" class="text-black"><span class="text-primary"> <img alt="" src="images/logo.png" style="width:80px"></a>
        <div class="d-flex align-items-center flex-column justify-content-between">
            <a style="color:brown;" href="login.php" class="px-2 py-1 text-dark"><i style="color: brown;" class="icon-user"></i> Login/Register</a>
            <div class="ps-2" id="google_translate_element"></div>
        </div>
    </div>
</div>