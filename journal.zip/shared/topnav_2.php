<div style="background-color:#EF949A;" class="px-4 py-1">
    <div class="text-end">
        <i class="icon-user"></i><a href="login.php" class="px-2 py-1 text-dark">Login/Register</a>
    </div>
</div>