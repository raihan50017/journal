<?php
$server = "localhost";
$user = "root";
$pass = "";
$database = "journal";
$conn  = mysqli_connect($server, $user, $pass, $database);
