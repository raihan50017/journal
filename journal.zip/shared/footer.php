<footer>
    <div style="background-color: rgba(0,0,0,.08);" class="border p-3 text-center mt-5">
        <p> &copy; All rights reserved by Jatiya Kabi Kazi Nazrul Islam University</p>
    </div>
</footer>