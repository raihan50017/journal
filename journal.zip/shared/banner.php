 <!-- banner -->
 <div>
     <div class="home-banner text-md-start text-center">
         <h2 class="fs-2">JKKNIU OPEN</h2>
         <h2 style="color:#EF949A" class="fs-2">OFFICIAL JOURNAl</h2>
     </div>
 </div>
 </div>
 <!-- banner -->