 <!-- banner -->
 <div>
     <div class="home-banner text-md-start text-center">
         <div class="row align-items-center">
             <div class="col-md-7">
                 <h2 class="fs-2">JKKNIU OPEN</h2>
                 <h2 style="color:#EF949A" class="fs-2">OFFICIAL JOURNAl</h2>
             </div>
             <div class="col-md-5">
                 <form>
                     <div class="input-group">
                         <input placeholder="search article" style="border-radius: 0px;" type="text" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                         <button style="border-radius: 0px;background-color:#EF949A;" class="btn banner-search-btn" type="button" id="inputGroupFileAddon04"><i class="icon-search"></i></button>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </div>
 </div>
 <!-- banner -->